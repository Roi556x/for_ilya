#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h> 
#include <unistd.h> 
//#include <winsock2.h>
#include <string.h>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <algorithm> 
#include <string>

using namespace std;

#define PORT 9909

class thread1{

    string line; //строка для цифр
    int linesize; //Размер строки

public:
    thread1(){}
    ~thread1(){}

 void input_line(int nSocket);
 void line_oper();

};

void thread1::input_line(int nSocket){
    bool error=0; // переменная для проверки ошибок

    cout<<endl<<"Enter a string consisting of digits."<<endl 
              <<"Maximum size of 64 characters\n Input: ";
    cin>>ws; // для повторного ввода строки иначе cin.ignore
    //fflush(stdin); // очистка буфера
    getline(cin, line); //Ввод строки

    linesize = line.size();

    //1) условие
    if(linesize>64){
    cout<<endl<<"You have entered more than 64 characters"<<endl;
    error = 1;
    }
    //2) уловие
     for (int i = 0; i<linesize; i++)
        {
        if(isdigit(line[i]))
            continue;
        else{
        cout<<endl<<"The string must consist only of digits"<<endl;
        error = 1;
        break;
        }
        }
        if (error == 1) 
        {
                bool temp;
                cout<<endl<<"Run it again? (1(yes)/0(no)): "; cin>>temp;
                if(temp){
                        line.clear();
                        input_line(nSocket); //Повторяем ввод строки и заново передаем данные о сокете
                }
                else
                {
                    char ch[64] = "exit";
                    //write(sockfd, ch, sizeof(ch));//Посылаем сигнал для прекращения работы второй программы
                    return exit(0);
                }
        }    
 }
void thread1::line_oper(){
ofstream fout("cpp.txt"); 
sort(line.begin(), line.end()); //отсортировали строку
reverse(line.begin(), line.end()); // реверсировали строку

string answer;
for (int i = 0; i < line.size(); i++){
    if(((int)line[i]-48)%2==0) // если число четное
        answer+="KB";
    else
    answer+=line[i];
}

fout<<answer; //запись ответа в файл
fout.close();
}

class thread2{

        string line2; //строка
        int linesize2; //длина строки
        char buff[80]; //сюда скопируем строку и передадим в программу 2
        int sum;
    public:

    thread2() : sum(0) {};
    ~thread2() {}

    //Перемещаем данные из файла в строку для дальнейшей обработки данных
        void from_file()
        {

        ifstream in("cpp.txt");
       if (in.is_open())
        {
        in>>line2;
        //cout<<endl<<"good";
        }
        in.close();

            ofstream toclearfile = ofstream("cpp.txt"); // зачистка
            toclearfile.close();

        }
    //Производим рассчет суммы чисел строки
    
        void get_summ()
        {
            cout<<endl<<"A string received from the shared buffer: "<<line2<<endl;
            linesize2 = line2.size();
            int *arr=new int[linesize2]; 
            arr[0]=0;
                int j=0;
                sum = 0;

                for (int i = 0; i<linesize2; i++) 
                    {
                        if(isdigit(line2[i]))
                        {
                            sum += (int)line2[i] - 48;
                        }
                    }     
                cout << "Sum of array is = " << sum << endl; 
            delete [] arr;
        }

    //Посылаем полученную сумму в программу 2 
    
        void sendToServer(int nSocket)
        {
            memset(buff, 0, sizeof(buff));
            sprintf(buff,"%d",sum);
            write(nSocket,buff,sizeof(buff)); //передаем данные в программу 2
        }

};

int main()
{
int nSocket, connfd; //параметры сокета
struct sockaddr_in srv, cli; 

// Создание и верификация сокета, 
// в программах будем использовать сокеты TCP
// 1-я программа - Клиент; 2-я программа - сервер.
	nSocket = socket(AF_INET, SOCK_STREAM, 0); 
	if (nSocket < 0) { 
		cout<<endl<<"The socket not opened"; 
		exit(0); 
	} 
	else
		cout<<endl<<"The socket opened successfully"; 

        // Назначение IP-адреса и Порта
	srv.sin_family = AF_INET; 
	srv.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	srv.sin_port = htons(PORT);
        memset(&(srv.sin_zero),0,8);


// Подключение сокета-клиента к сокету-серверу
	if (connect(nSocket, (sockaddr*)&srv, sizeof(srv)) < 0) { 
		cout<<endl<<"Connection with the server failed";  
		exit(0); 
	} 
	else
		cout<<endl<<"Successfully connect to server"; 

thread1 t1; // 1 поток
thread2 t2; // 2 поток
bool temp;

while(true){
    t1.input_line(nSocket); // получаем строку (проверяем строку)
    t1.line_oper();
    t2.from_file(); // чтение из файла в строку
    t2.get_summ(); // производим рассчет суммы численных элементов строки
    t2.sendToServer(nSocket);

    cout<<endl<<"Run it again? (1(yes)/0(no)): "; cin>>temp;
    if(!temp) break;
    }

 char ch[80] = "exit";
    write(nSocket, ch, sizeof(ch)); 
	close(nSocket); 

cin.get();
return 0;
}